import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Scanner } from "@/components/Scanner";
import { ProductCard } from "@/components/ProductCard";
import { useToast } from "@/hooks/use-toast";
import type { Product } from "@shared/schema";

export default function Home() {
  const [isScanning, setIsScanning] = useState(false);
  const [scannedCode, setScannedCode] = useState<string | null>(null);
  const { toast } = useToast();

  const { data: product, isLoading } = useQuery<Product>({
    queryKey: scannedCode ? ['/api/products', scannedCode] : [],
    enabled: !!scannedCode,
  });

  const handleDetected = (code: string) => {
    setScannedCode(code);
    setIsScanning(false);
    toast({
      title: "Barcode Detected",
      description: `Scanning barcode: ${code}`,
    });
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold">Barcode Scanner</h1>
          <p className="text-muted-foreground">
            Scan a product barcode to view details
          </p>
        </div>

        <Scanner
          onDetected={handleDetected}
          isScanning={isScanning}
          onToggleScanner={() => setIsScanning(!isScanning)}
        />

        {scannedCode && product && !isLoading && (
          <ProductCard 
            product={product} 
            isLoading={isLoading}
          />
        )}

        {scannedCode && isLoading && (
          <ProductCard 
            product={undefined as any}
            isLoading={true}
          />
        )}
      </div>
    </div>
  );
}