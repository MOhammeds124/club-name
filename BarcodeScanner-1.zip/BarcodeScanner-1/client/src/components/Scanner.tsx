import { useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface ScannerProps {
  onDetected: (code: string) => void;
  isScanning: boolean;
  onToggleScanner: () => void;
}

// Global declaration for Quagga
declare const Quagga: any;

export function Scanner({ onDetected, isScanning, onToggleScanner }: ScannerProps) {
  const scannerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    let mounted = true;

    const initializeScanner = async () => {
      if (!isScanning || !scannerRef.current) return;

      try {
        await new Promise((resolve, reject) => {
          Quagga.init(
            {
              inputStream: {
                name: "Live",
                type: "LiveStream",
                target: scannerRef.current,
                constraints: {
                  facingMode: "environment",
                },
              },
              decoder: {
                readers: ["ean_reader", "ean_8_reader", "upc_reader", "upc_e_reader"],
              },
            },
            (err: Error | null) => {
              if (err) {
                reject(err);
                return;
              }
              resolve(true);
            }
          );
        });

        if (mounted) {
          Quagga.start();

          Quagga.onDetected((result: { codeResult: { code: string } }) => {
            if (result.codeResult.code) {
              onDetected(result.codeResult.code);
            }
          });
        }
      } catch (err) {
        toast({
          variant: "destructive",
          title: "Camera Error",
          description: "Could not access camera. Please ensure camera permissions are granted.",
        });
      }
    };

    initializeScanner();

    return () => {
      mounted = false;
      if (typeof Quagga !== 'undefined' && Quagga.stop) {
        Quagga.stop();
      }
    };
  }, [isScanning, onDetected, toast]);

  return (
    <Card className="w-full max-w-lg mx-auto overflow-hidden">
      <div className="relative">
        <div 
          ref={scannerRef} 
          className="w-full aspect-video bg-black"
        />
        <div className="absolute inset-0 border-2 border-primary opacity-50 pointer-events-none">
          <div className="absolute top-1/2 w-full border-t-2 border-primary"></div>
        </div>
      </div>
      <div className="p-4">
        <Button 
          onClick={onToggleScanner}
          className="w-full"
          variant={isScanning ? "destructive" : "default"}
        >
          {isScanning ? "Stop Scanner" : "Start Scanner"}
        </Button>
      </div>
    </Card>
  );
}