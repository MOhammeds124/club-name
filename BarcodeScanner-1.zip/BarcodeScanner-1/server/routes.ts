import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

const mockProducts = [
  {
    id: 1,
    barcode: "123456789",
    name: "Sample Product 1",
    description: "A high quality sample product",
    price: 1999,
    imageUrl: "https://placehold.co/400x300"
  },
  {
    id: 2, 
    barcode: "987654321",
    name: "Sample Product 2", 
    description: "Another excellent sample product",
    price: 2999,
    imageUrl: "https://placehold.co/400x300"
  }
];

export function registerRoutes(app: Express): Server {
  // Get product by barcode
  app.get("/api/products/:barcode", (req, res) => {
    const product = mockProducts.find(p => p.barcode === req.params.barcode);
    
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    return res.json(product);
  });

  const httpServer = createServer(app);
  return httpServer;
}
